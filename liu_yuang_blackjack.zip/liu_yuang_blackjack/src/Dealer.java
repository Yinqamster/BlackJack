
public class Dealer extends Person{
    public Dealer(String name) {
        super(name);
    }

    public Dealer() {
        super("Computer");
    }
}
