
public class Bet {
	// set the bet of each round
	private int bet;
	
	public Bet(){}
	
	public Bet(int bet) {
		this.bet = bet;
	}
	
	public int getBet(){
		return this.bet;
	}
	
	public void setBet(int bet) {
		this.bet = bet;
	}
}
